package com.udea.aerolinea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AerolineaApplicationTests {

    @Test
    void contextLoads() {
    }

}
